export interface NumberedPagination {
  index: number;
  totalPages: number;
  pages: number[];
}
