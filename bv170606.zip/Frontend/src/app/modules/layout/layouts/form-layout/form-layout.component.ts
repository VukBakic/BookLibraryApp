import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-layout',
  templateUrl: './form-layout.component.html',
})
export class FormLayoutComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
