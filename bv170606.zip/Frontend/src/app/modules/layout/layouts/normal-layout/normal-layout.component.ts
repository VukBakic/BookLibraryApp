import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-normal-layout',
  templateUrl: './normal-layout.component.html',
})
export class NormalLayoutComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
