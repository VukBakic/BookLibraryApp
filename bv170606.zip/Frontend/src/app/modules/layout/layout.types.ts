export type Layout = 'normal' | 'form' | 'auth';
