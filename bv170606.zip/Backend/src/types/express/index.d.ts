declare namespace Express {
  interface Request {
    avatar: any;
    image: any;
    jwtData: any;
    updated: any;
    pending: any;
  }
}
